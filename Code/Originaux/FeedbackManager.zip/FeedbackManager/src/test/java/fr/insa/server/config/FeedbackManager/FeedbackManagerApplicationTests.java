package fr.insa.server.config.FeedbackManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
