package fr.insa.server.config.FeedbackManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackManagerApplication.class, args);
	}

}
