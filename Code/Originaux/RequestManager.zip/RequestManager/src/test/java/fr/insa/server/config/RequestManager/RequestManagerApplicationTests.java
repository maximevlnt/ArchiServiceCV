package fr.insa.server.config.RequestManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RequestManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
