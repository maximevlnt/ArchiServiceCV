package fr.insa.server.config.AffectationManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AffectationManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
