package fr.insa.server.config.AffectationManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AffectationManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AffectationManagerApplication.class, args);
	}

}
